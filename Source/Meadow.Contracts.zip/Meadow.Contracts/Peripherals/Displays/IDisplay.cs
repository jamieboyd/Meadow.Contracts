﻿namespace Meadow.Peripherals.Displays
{
    /// <summary>
    /// Display Interface
    /// </summary>
    public interface IDisplay
    {
    }
}
