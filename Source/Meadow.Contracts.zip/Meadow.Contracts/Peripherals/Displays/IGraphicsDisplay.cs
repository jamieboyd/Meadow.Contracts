﻿namespace Meadow.Peripherals.Displays
{
    public interface IGraphicsDisplay : IDisplay
    {
    }
}
