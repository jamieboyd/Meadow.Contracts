﻿namespace Meadow.Peripherals.Relays
{
    /// <summary>
    /// Relay Type
    /// </summary>
    public enum RelayType
    {
        NormallyOpen,
        NormallyClosed
    }
}
