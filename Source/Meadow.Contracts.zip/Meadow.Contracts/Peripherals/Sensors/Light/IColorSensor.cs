﻿//using Meadow.Units;
//using System;

//namespace Meadow.Peripherals.Sensors.Light
//{
//    /// <summary>
//    /// Light sensor interface requirements.
//    /// </summary>
//    public interface IColorSensor : ISensor
//    {
//        /// <summary>
//        /// Last value read from the color sensor.
//        /// </summary>
//        Color? Color { get; }

//        /// <summary>
//        /// Raised when a change in light is detected.
//        /// </summary>
//        event EventHandler<IChangeResult<Illuminance>> LuminosityUpdated;
//    }
//}