﻿namespace Meadow.Peripherals.Sensors
{
    //TODO: after Meadow.Foundation cleanup. Get rid of comments
    // here and enforce this pattern.

    public interface ISensor/*<UNIT>
        where UNIT : struct*/
    {
        /*
        bool IsSampling { get; }

        UNIT Read();
        void StartUpdating();
        void StartUpdated(TimeSpan updateInterval, int sampleCount, TimeSpan sampleInterval);
        void StopUpdating();
        */
    }
}
