﻿using System;
namespace Meadow.Hardware
{
    public enum SerialDirectionType
    {
        Receive,
        Transmit
    }
}
