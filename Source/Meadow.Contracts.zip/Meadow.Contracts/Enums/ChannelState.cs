﻿namespace Meadow.Hardware
{
    public enum ChannelState
    {
        Unknown,
        NotInUse,
        InUse,
    }

}

