﻿namespace Meadow.Gateways.Bluetooth
{
    public interface IJsonSerializable
    {
        string ToJson();
    }
}
