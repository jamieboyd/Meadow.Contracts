﻿namespace Meadow.Hardware
{
    public enum ChipSelectMode
    {
        ActiveLow,
        ActiveHigh
    }
}
