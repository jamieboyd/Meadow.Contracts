﻿using System;
namespace Meadow.Hardware
{
    public interface IDigitalInputOutputController : IDigitalInputController, IDigitalOutputController
    {
    }
}
