﻿using System;
namespace Meadow.Hardware
{
    public interface ICommunicationChannelInfo
    {
    }
}
