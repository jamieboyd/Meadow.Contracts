//namespace Meadow.Gateways
//{
//    // For future use
//    public interface INetworkAdapter
//    {
        
//    }
//}